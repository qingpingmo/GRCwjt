from setuptools import setup, find_packages

setup(
    name="GRCwjt",
    packages=find_packages(),
    version="0.0.5",
    install_requires=[
        "rpyc",
        "pyelftools",
        "find_libpython"
    ],
    author="",
    author_email="",
)